// console.log("Node js is here...!");

const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const cors = require("cors");
const mongoose = require("mongoose");
const users = require("./routes/users");
const config = require("./config/database");
const User = require("./models/user");


const app = express();
const port = 3000;

mongoose.connect(config.database);
mongoose.Promise = global.Promise;

mongoose.connection.on("connected", () => {
    console.log("WOW....! Connected to mongodb");
});

mongoose.connection.on("error", (err) => {
    console.log("Failed to connect to Mongodb : " + err);
});


// Set local variables
app.use(function (req, res, next) {
    res.locals.errors = null;
    res.locals.activeClass = "home";
    next();
});


app.set("view engine", "ejs");
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'assets')));

// Users router
app.use("/users", users);

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Array of objects of users
var docs = [
    {
        "first_name": "Manoj",
        "last_name": "Kumar",
        "age": "25"
    },
    {
        "first_name": "Mahesh",
        "last_name": "Kumar",
        "age": "23"
    },
    {
        "first_name": "Kranthi",
        "last_name": "Kumar",
        "age": "18"
    }
];
// Global end point
app.get("/ejs", (req, res) => {
    // res.send("You are in Global area of this app...!");
    res.render('customers', {
        title: "Customers",
        users: docs
    });
});


// Global end point
app.get("/", (req, res) => {
    // res.send("You are in Global area of this app...!");
    res.render("index", {
        activeClass: "home"
    });
});


app.get("/register", (req, res) => {
    // res.send("You are in Global area of this app...!");
    res.render("register", {
        activeClass: "register"
    });
});


app.post("/register", (req, res) => {
    console.log(req.body);
    let newUser = new User({
        first_name: req.body.first_name,
        last_name: req.body.last_name,
        email: req.body.email,
        gender: req.body.gender,
        phone_number: req.body.phone_number,
        username: req.body.username,
        password: req.body.password
    });


    User.addUser(newUser, (err, user) => {
        if (err) {
            res.json({ success: false, msg: 'Failed to register user ' + err });
        } else {
            // res.json({ success: true, msg: 'User registered' });
            res.redirect('/all_users');
        }
    });
});


app.get("/login", (req, res) => {
    // res.send("You are in Global area of this app...!");
    res.render("login", {
        activeClass: "login"
    });
});

app.get("/all_users", (req, res) => {
    // res.send("You are in Global area of this app...!");
    /*
    res.render("all_users", {
        activeClass: "all_users"
    });
    */
    User.find({}, (err, data) => {
        if (err) {
            res.send("Something went wrong in fetching the data from database.");
        } else {
            res.render("all_users", {
                data: data,
                activeClass: "all_users"
            });
        }
    });
});


// Assigning a port to app to listen
app.listen(port, () => {
    console.log("Server started at port: " + port);
});