const express = require("express");
const User = require("../models/user");
const bodyParser = require("body-parser");
const router = express.Router();
const path = require("path");

router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());


router.get("/", (req, res) => {
    // res.send("You are in Global area of 'User' router");
    // res.contentType("text/html");
    res.sendFile(path.join(__dirname, "../public/coming_soon_1.html"));
});

router.post(("/delete/:id"), (req, res) => {
    // console.log(req.params);
    let deletableId = req.params.id;
    var result = "";
    console.log(deletableId);
    User.findByIdAndRemove(deletableId, (err, data) => {
        if (err) {
            console.log("Deletion failed");
            result = "failed";
        } else {
            console.log("Deletion completed...!");
            result = "success";
        }
        res.json({ result: result });
    });
});

router.get("/edit/:username", (req, res) => {
    let getUsername = req.params.username;
    var requestStatus = "";
    console.log(getUsername);
    User.findOne({ username: getUsername }, (err, data) => {
        if (err) {
            console.log("No records found... :(");
            requestStatus = "error";
            this.data = null;
        } else {
            console.log("wohooo...! Record found");
            console.log(data);
            requestStatus = "success";
        }
        res.render("edit", {
            activeClass: "register",
            status: requestStatus,
            data: data
        })
    });
});


router.post(("/edit"), (req, res) => {
    console.log(req.body);
    let getId = req.body.id;
    console.log(getId);

    var newUser = {
        first_name: req.body.first_name,
        last_name: req.body.last_name,
        email: req.body.email,
        gender: req.body.gender,
        phone_number: req.body.phone_number,
        username: req.body.username,
        password: req.body.password
    };

    User.findByIdAndUpdate(getId, { $set: newUser }, (err, data) => {
        if (err) {
            console.log("Failed, User updation has been failed.");
        } else {
            console.log("Success, user information updated successfully");
            res.redirect("/users/edit/" + newUser.username);
        }
    });

});

module.exports = router;