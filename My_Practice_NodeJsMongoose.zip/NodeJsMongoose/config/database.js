module.exports = {
    database: "mongodb://localhost:27017/nodejsmongoose",
    secretKey: "1234567890"
};